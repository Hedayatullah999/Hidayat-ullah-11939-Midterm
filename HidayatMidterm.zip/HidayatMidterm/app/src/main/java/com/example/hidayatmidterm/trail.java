package com.example.hidayatmidterm;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

import java.util.List;

public class trail extends ArrayAdapter<Nws>
{
    private int resourceLayout;
    private Context mContext;
    private List<Nws>itemList;

    public trail(Context context, int resource, List<Nws> items)
    {
        super(context, resource, items);
        this.resourceLayout = resource;
        this.itemList=items;
        this.mContext = context;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {

        View v = convertView;

        if (v == null)
        {
            LayoutInflater vi;
            vi = LayoutInflater.from(mContext);
            v = vi.inflate(resourceLayout, null);
        }

        Nws item = getItem(position);

        TextView tvHeading=v.findViewById(R.id.tv_heading);
        TextView tvDesc=v.findViewById(R.id.tv_desc);
        TextView tvUrl=v.findViewById(R.id.tv_url);
        TextView tvID=v.findViewById(R.id.tv_id);
        ImageView img=v.findViewById(R.id.img_view);

        tvHeading.setText("Heading: "+item.getHeading());
        tvDesc.setText("Description: "+item.getDescription());
        tvUrl.setText("URL:"+item.getUrl());
        tvID.setText("ID:" +String.valueOf(item.getId()));
        Glide.with(mContext).load(item.getUrl()).into(img);

        return v;
    }

}